import pandas as pd

test_df = pd.read_csv("data_schema.csv")

# print(test_df['columns'].values)

print(test_df.head(1))