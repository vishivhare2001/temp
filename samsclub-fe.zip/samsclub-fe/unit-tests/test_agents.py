import unittest
import os
import sys
import pandas as pd

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)
sys.path.append(PROJECT_ROOT)

from lib_ds.genai.selector_agent import SelectorAgent
from lib_ds.genai.decomposer_agent import DecomposerAgent
from lib_ds.genai.refiner_agent import RefinerAgent
from lib_ds.genai.master_conversation_agent import ConversationAgent
from lib_ds.genai.plot_agent import PlotAgent
from lib_ds.data_loader.bigquery.sql import SQLExecutor
from etc.llm_app_env import DATABASE_TABLE_NAME

class TestAgents(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        """Load shared resources for all tests."""
        cls.selector_agent = SelectorAgent()
        cls.decomposer_agent = DecomposerAgent()
        cls.refiner_agent = RefinerAgent()
        cls.conversation_agent = ConversationAgent()
        cls.plot_agent = PlotAgent()
        cls.sql_executor = SQLExecutor()

        # Load database schema
        schema_path = os.path.join(PROJECT_ROOT, "data", "data_schema.csv")
        if not os.path.exists(schema_path):
            raise FileNotFoundError(f"Schema file not found at {schema_path}")
        cls.schema_json = pd.read_csv(schema_path).to_dict(orient='records')

        # Load user questions
        questions_file = os.path.join(PROJECT_ROOT, "data", "user_questions.txt")
        if not os.path.exists(questions_file):
            raise FileNotFoundError(f"User questions file not found at {questions_file}")
        with open(questions_file, "r") as file:
            cls.user_questions = [line.strip() for line in file.readlines() if line.strip()]

    def test_selector_agent(self):
        """Test the SelectorAgent with user questions."""
        for question in self.user_questions:
            response = self.selector_agent.invoke_agent(question, self.sql_executor)
            self.assertIsInstance(response, dict, "SelectorAgent response should be a dictionary.")
            self.assertIn("success", response, "SelectorAgent response should contain 'success'.")
            self.assertIn("selected_tables", response, "SelectorAgent response should contain 'selected_tables'.")
            print(f"SelectorAgent - Question: {question}\nResponse: {response}\n")

    def test_decomposer_agent(self):
        """Test the DecomposerAgent with user questions."""
        for question in self.user_questions:
            output, response = self.decomposer_agent.invoke_agent(question, self.schema_json)
            self.assertIsInstance(response, dict, "DecomposerAgent response should be a dictionary.")
            self.assertIn("success", response, "DecomposerAgent response should contain 'success'.")
            print(f"DecomposerAgent - Question: {question}\nResponse: {response}\n")

    def test_refiner_agent(self):
        """Test the RefinerAgent with a sample query."""
        user_question = "What is the total sales amount for the last month?"
        sql_query = "SELECT SUM(amount) FROM sales_data WHERE date > DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH)"
        thought_str, response = self.refiner_agent.invoke_agent(user_question, self.schema_json, sql_query)

        self.assertIsInstance(response, dict, "RefinerAgent response should be a dictionary.")
        self.assertIn("Final_query", response, "RefinerAgent response should contain 'Final_query'.")
        print(f"RefinerAgent - Refined Query:\n{response['Final_query']}\n")

    def test_conversation_agent(self):
        """Test the ConversationAgent with user questions."""
        for question in self.user_questions:
            response = self.conversation_agent.invoke_agent(question)
            self.assertIsInstance(response, dict, "ConversationAgent response should be a dictionary.")
            self.assertIn("Enhanced_Question", response, "ConversationAgent response should contain 'Question'.")
            print(f"ConversationAgent - Reformulated Question: {response['Enhanced_Question']}\n")

    def test_plot_agent(self):
        """Test the PlotAgent with a valid visualization request."""
        user_question = "Show me the sales trend over time."
        schema_json = {"columns": [{"name": "date", "dtype": "datetime"}, {"name": "sales", "dtype": "float"}]}
        output_text, response = self.plot_agent.invoke_agent(user_question, schema_json)

        self.assertIsInstance(response, dict, "PlotAgent response should be a dictionary.")
        self.assertIn("code", response, "PlotAgent response should contain 'code'.")
        print(f"PlotAgent - Generated Code:\n{response['code']}\n")

if __name__ == "__main__":
    unittest.main()
