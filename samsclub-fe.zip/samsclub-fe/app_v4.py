import streamlit as st
import sqlparse
import pandas as pd
import time
from lib_ds.processor.multi_agent_processor import MultiAgentProcessor
from lib_ds.genai.master_conversation_agent import ConversationAgent
from lib_ds.genai.plot_agent import PlotAgent
from lib_ds.utils.logger import Logger
from etc.llm_app_env import LOGLEVEL
from etc.api_key import API_KEY  # if needed

logger = Logger.get_logger(LOGLEVEL=LOGLEVEL)

# Initialize core objects
proc_obj = MultiAgentProcessor()
conversation_agent = ConversationAgent()
plot_agent = PlotAgent()

st.set_page_config(page_title="Text 2 SQL Helper", layout="wide")

def reset_session():
    st.session_state.clear()
    st.rerun()

if st.sidebar.button("🔄 Reset Session"):
    reset_session()

st.title("Text 2 SQL Helper")

# Sidebar settings for a minimalistic UI
with st.sidebar:
    st.subheader("Settings")
    enable_plotting = st.checkbox("Enable Data Visualization", value=True)
    show_agent_reasons = st.checkbox("Show Agent Reasoning", value=True)
    show_sql_queries = st.checkbox("Show SQL Queries", value=True)
    
    # Display chat history if available
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    if st.session_state.chat_history:
        st.subheader("Chat History")
        for chat in st.session_state.chat_history:
            st.write(f"**User:** {chat['user']}")
            st.write(f"**Bot:** {chat['bot']}")
            st.write("---")

# Initialize session state variables
for key in ["conversation_response", "selector_output", "sql_query", "query_result", "execution_times", "user_modified_query", "last_enhanced_query", "api_call_count"]:
    if key not in st.session_state:
        st.session_state[key] = 0 if key == "api_call_count" else None

st.write("### 💬 Chat with AI")
user_input = st.text_input("Enter your question:")

if user_input:
    with st.spinner("Processing your query..."):
        st.session_state.execution_times = {}
        start_time = time.time()
        # Conversation Agent: Enhance/rephrase the user query
        conversation_response = proc_obj.execute_conversation_agent(user_input)
        st.session_state.api_call_count += 1
        st.session_state.execution_times["ConversationAgent"] = round(time.time() - start_time, 2)
        enhanced_query = conversation_response.get("Enhanced_Question", user_input)
        st.session_state.conversation_response = enhanced_query
        st.session_state.last_enhanced_query = enhanced_query
        st.session_state.chat_history.append({"user": user_input, "bot": enhanced_query})
    
    with st.container():
        st.subheader("💬 Conversation Agent Output")
        if enhanced_query:
            st.write(f"**Enhanced Query:** {enhanced_query}")
            st.write(f"⏱️ Execution Time: {st.session_state.execution_times['ConversationAgent']}s")
        else:
            st.error("Conversation agent did not return a valid query. Please try again.")
            st.stop()
    
    # Allow optional modification to the enhanced query
    user_modified_query = st.text_area("Modify AI-generated query (optional):", enhanced_query)
    
    if st.button("Execute Query"):
        st.session_state.user_modified_query = user_modified_query

        # Selector Agent
        with st.spinner("Selecting relevant tables..."):
            start_time = time.time()
            selector_output = proc_obj.execute_selector(st.session_state.user_modified_query)
            st.session_state.api_call_count += 1
            st.session_state.execution_times["SelectorAgent"] = round(time.time() - start_time, 2)
            st.session_state.selector_output = selector_output

        with st.container():
            st.subheader("🔍 Selector Agent Output")
            if selector_output.get("success") == "True":
                st.json(selector_output.get("selected_tables", []))
                st.write(f"⏱️ Execution Time: {st.session_state.execution_times['SelectorAgent']}s")
                if show_agent_reasons:
                    st.markdown("#### Selector Agent Reasoning")
                    st.write(selector_output.get("reason", "No reasoning available."))
            else:
                st.error("Selector agent did not find relevant tables for the query.")
                st.stop()

        # Decomposer Agent
        with st.spinner("Generating SQL Query..."):
            start_time = time.time()
            thought_str, decomposer_output = proc_obj.execute_decomposer()
            st.session_state.api_call_count += 1
            st.session_state.execution_times["DecomposerAgent"] = round(time.time() - start_time, 2)
            st.session_state.sql_query = decomposer_output.get("SQL_response", "").strip()
        with st.container():
            st.subheader("📝 Decomposer Agent Output")
            if st.session_state.sql_query:
                if show_sql_queries:
                    st.code(st.session_state.sql_query, language="sql", wrap_lines = True, line_numbers= True)
                st.write(f"⏱️ Execution Time: {st.session_state.execution_times['DecomposerAgent']}s")
                if show_agent_reasons:
                    st.markdown("#### Decomposer Agent Reasoning")
                    st.write(decomposer_output.get("Reason", "No reasoning available."))
            else:
                if show_agent_reasons:
                    st.markdown("#### Decomposer Agent Reasoning")
                    st.write(decomposer_output.get("Reason", "No reasoning available."))
                st.error("Decomposer agent did not generate a valid SQL query.")
                st.stop()

        # Refiner Agent
        with st.spinner("Refining SQL Query..."):
            start_time = time.time()
            thought_str, refiner_output, query_result = proc_obj.execute_refiner()
            st.session_state.api_call_count += 1
            st.session_state.execution_times["RefinerAgent"] = round(time.time() - start_time, 2)
            refined_query = refiner_output.get("Final_query", "").strip()

            # Display the refined query only if it's different from the decomposer's query
            if refined_query and refined_query != st.session_state.sql_query:
                st.session_state.sql_query = refined_query
                show_refined_query = True
            else:
                show_refined_query = False

            st.session_state.query_result = query_result

        # Display Refiner Output only if query changed
        with st.container():
            st.subheader("✅ Refiner Agent Output")
            if show_refined_query:
                if show_sql_queries:
                    st.code(st.session_state.sql_query, language="sql", wrap_lines = True, line_numbers= True)
                st.write(f"⏱️ Execution Time: {st.session_state.execution_times['RefinerAgent']}s")
            else:
                st.info("Refined query is identical to decomposed query. No changes made.")


        # Query Results
        with st.container():
            st.subheader("📊 Query Results")
            if st.session_state.query_result is not None and not st.session_state.query_result.empty:
                st.dataframe(st.session_state.query_result)
            else:
                st.error("No results returned by the query.")
                st.stop()

        # Visualization Section (if enabled)
        if enable_plotting:
            if st.session_state.query_result is not None and not st.session_state.query_result.empty:
                with st.spinner("Generating Visualization..."):
                    # Extract schema dynamically from the query result
                    query_schema = [
                        {"name": col, "dtype": str(st.session_state.query_result[col].dtype)}
                        for col in st.session_state.query_result.columns
                    ]
                    
                    # Invoke plot agent with the correct schema
                    plot_text, plot_response = plot_agent.invoke_agent(
                        user_question=st.session_state.user_modified_query,
                        schema_json={"columns": query_schema}
                    )

                    if "code" in plot_response:
                        try:
                            # Prepare execution context
                            exec_globals = {"df": st.session_state.query_result}
                            exec(plot_response["code"], exec_globals)

                            # Check if any figure was created
                            if "fig" in exec_globals:
                                st.plotly_chart(exec_globals["fig"])
                            else:
                                st.warning("Plot generated, but no figure object found.")
                        except Exception as e:
                            st.error(f"Error executing plot: {e}")
                    else:
                        st.warning("No plot generated for this query.")


        # Execution summary
        with st.container():
            st.subheader("⏳ Execution Summary")
            for agent, t in st.session_state.execution_times.items():
                st.write(f"**{agent}:** {t}s")
            st.write(f"**Total OpenAI API Calls:** {st.session_state.api_call_count}")
