import logging
import os
import sys


class CustomFilter(logging.Filter):
    """A custom logging filter to enhance log records with additional information.

    Args:
        logging (_type_): _description_
    """    
    def filter(self, record):
        """Modifies the log record by adding a 'filename_lineno' attribute and returns True to allow the log record.
        
        Args:
            record (LogRecord): The log record to be modified.

        Returns:
            bool: True to allow the log record.
        """        
        record.filename_lineno = "%s:%d" % (record.filename, record.lineno)
        return True

class Logger:
    """A class for creating and managing logger instances with different log levels.

    Attributes:
        GLOBAL_LOGGER (dict): A dictionary to store and reuse logger instances based on process ID and log level.
    """    
    GLOBAL_LOGGER = {}

    def __init__(self):
        """Raises NotImplementedError to prevent creating an object of this class.
        """        
        raise NotImplementedError("Cannot create a object of this class, use get_logger method")

    @classmethod
    def get_logger(self, LOGLEVEL):
        """Retrieves or creates a logger instance based on the specified log level.

        Summary:  
            The 'Logger' class provides a convenient way to manage logger instances across different log levels.
            Logger instances are stored in the 'GLOBAL_LOGGER' dictionary for reuse based on process ID and log level.
            The 'get_logger' method allows users to retrieve an existing logger instance or create a new one.
            Log levels supported: 'debug', 'info', 'warning', 'error', 'critical'.
            Each logger instance is configured with a custom filter ('CustomFilter') to enhance log records.
            Log records include additional information such as filename and line number for improved debugging.

        Args:
            LOGLEVEL (str): The desired log level ('debug', 'info', 'warning', 'error', 'critical').

        Raises:
            ValueError: _description_

        Returns:
            logging.Logger: The logger instance associated with the specified log level.
        """        
        pid_key = "{}_{}".format(str(os.getpid()), LOGLEVEL.lower())
        if pid_key not in Logger.GLOBAL_LOGGER.keys():

            if LOGLEVEL.lower() == 'debug':
                level = logging.DEBUG
            elif LOGLEVEL.lower() == 'info':
                level = logging.INFO
            elif LOGLEVEL.lower() == 'warning':
                level = logging.WARNING
            elif LOGLEVEL.lower() == 'error':
                level = logging.ERROR
            elif LOGLEVEL.lower() == 'critical':
                level = logging.CRITICAL
            else:
                raise ValueError("Please provide a correct logging level. loglevel given : {}".format(LOGLEVEL))

            log_object = logging.getLogger(pid_key)
            log_object.setLevel(level)
            log_object.addFilter(CustomFilter())
            streamhandler = logging.StreamHandler(stream=sys.stdout)
            formatter = logging.Formatter(
                '%(asctime)s %(levelname)-7s %(filename_lineno)-27s : %(message)s')
            streamhandler.setFormatter(formatter)

            log_object.addHandler(streamhandler)

            Logger.GLOBAL_LOGGER[pid_key] = log_object

        return Logger.GLOBAL_LOGGER[pid_key]