import os
import pandas as pd
from google.cloud import bigquery
from etc.llm_app_env import GOOGLE_APPLICATION_CREDENTIALS, TABLE_COLUMN_DESC, DATABASE_TABLE_NAME


class SQLExecutor:
    def __init__(self) -> None:
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = GOOGLE_APPLICATION_CREDENTIALS #cred_file
        self.client = bigquery.Client()

    def execute_query(self, query):
        result_dict = self.client.query(query) 
        return result_dict
    
    def load_database_schema_json(self, output_type = "json"):
        # query = """
        # SELECT table_name, column_name, description, data_type
        # FROM `{}.INFORMATION_SCHEMA.COLUMN_FIELD_PATHS`
        # """.format(DATABASE_TABLE_NAME)
        # df = self.execute_query(query).to_dataframe()
        # grouped = df.groupby('table_name').apply(lambda x: list(zip(x['column_name'], x['description'], x["data_type"])))
        # final_df = pd.DataFrame({'table_name': grouped.index,'columns': grouped.values})
        # final_df['columns'] = final_df['columns'].apply(lambda x: [{'column_name': k, 'column_description': v, 'data_type': l} for k,v,l in x])
        # df_tb_desc = pd.read_csv(TABLE_COLUMN_DESC)[["table_name", "table_description"]]
        # final_df = pd.merge(.df_tb_desc, final_df, on="table_name")

        final_df = pd.read_csv(TABLE_COLUMN_DESC)

        if output_type == "dataframe":
            return final_df
        schema_json = final_df.to_dict(orient='records')
        return schema_json