import pandas as pd
from langchain.agents import AgentExecutor
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain.output_parsers import StructuredOutputParser, ResponseSchema
from langchain_core.pydantic_v1 import BaseModel, Field
from langchain_core.agents import AgentActionMessageLog, AgentFinish
import json
from etc.api_key import API_KEY

from etc.llm_app_env import REFINER_LLM_CONFIG, REFINER_PROMPT_TEMPLATE, REFINER_RESPONSE_SCHEMA, AZURE_OPENAI_CONFIG

class Response(BaseModel):
    """Final response to the question being asked"""
    Selected_right_tables: str = Field(description="this should be 'Success' if the tables selected are correct and required for answering user's question or else 'Failed'")
    Bigquery_syntax: str = Field(description="this should be 'Success' if the code provided is syntactically correct and all the rules of bigquery syntax have been followed or else 'Failed'")
    Contextual_validation: str = Field(description="This should be 'Success' if input bigquery code is contextually correct to answer the user question else 'Failed'.")
    Contextual_validation_reason: str = Field(description="Provides reason for both success or failure of contextual validation")
    Result: str = Field(description="States whether the code is good to be run or not. If not, then it states what changes need to be made")
    Joins_used: str = Field(description="States whether the joins used are correct or not. If not, provide which join used is wrong.")
    Final_query: str = Field(description="Provides corrected and modified bigquery code if modified")
    Final_query_validation: str = Field(description="This will again validate the modified query if any changes were made, else states 'no changes were made'")

class RefinerAgent:   
    def __init__(self) -> None:
        self.llm = AzureChatOpenAI(
            deployment_name=AZURE_OPENAI_CONFIG["DEPLOYMENT_NAME"],
            azure_endpoint=AZURE_OPENAI_CONFIG["ENDPOINT"],
            openai_api_version=AZURE_OPENAI_CONFIG["API_VERSION"],
            openai_api_key=AZURE_OPENAI_CONFIG["API_KEY"],
            model_name=AZURE_OPENAI_CONFIG["MODEL_NAME"],
            temperature=AZURE_OPENAI_CONFIG["TEMPERATURE"]
        )

        self.PROMPT_TEMPLATE = REFINER_PROMPT_TEMPLATE
        self.response_schemas_dict = REFINER_RESPONSE_SCHEMA     
        self.tools = []
        
        response_schemas = [ResponseSchema(name=item['name'], description=item['description']) for item in self.response_schemas_dict] 
        self.output_parser_json = StructuredOutputParser.from_response_schemas(response_schemas)
        self.format_instructions = self.output_parser_json.get_format_instructions()
        self.agent = self.get_agent()

    def parse(self, output):
        if isinstance(output, str):
            return AgentFinish(return_values={"output": output}, log=output)

        if "function_call" not in output.additional_kwargs:
            return AgentFinish(return_values={"output": output.content}, log=output.content)

        function_call = output.additional_kwargs["function_call"]
        name = function_call["name"]
        inputs = json.loads(function_call["arguments"])

        if name == "Response":
            return AgentFinish(return_values=inputs, log=str(function_call))

        return AgentActionMessageLog(
            tool=name, tool_input=inputs, log="", message_log=[output]
    )

    def get_agent(self):
        prompt = ChatPromptTemplate.from_messages([
            ("system", self.PROMPT_TEMPLATE),
        ])
        return (
            {
                "user_question": lambda x: x["user_question"],
                "input_query": lambda x: x["input_query"],
                "db_schema": lambda x: x["db_schema"],
                "format_instructions": lambda x: x["format_instructions"]
            }
            | prompt
            | self.llm
            | self.parse
        )

    def invoke_agent(self, user_question, schema_json, sql_query):
        agent_executor = AgentExecutor(
            agent=self.agent,
            tools=[],
            verbose=True
        )
        result = agent_executor.invoke({
            "user_question": user_question,
            "input_query": sql_query,
            "db_schema": schema_json,
            "format_instructions": self.format_instructions
        })        
        return result['output'], self.custom_parse_json(result['output'])

    def custom_parse_json(self, llm_response):
        try:
            return self.output_parser_json.parse(llm_response)
        except:
            try:
                json_data = json.loads(llm_response.split("json")[-1].replace("```", ""))
            except:
                json_data = {"error": "JSON Parsing error"}
        return json_data
