import json
import textwrap
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain.output_parsers import StructuredOutputParser, ResponseSchema
from langchain.agents import AgentExecutor
from langchain_core.agents import AgentActionMessageLog, AgentFinish
from etc.api_key import API_KEY


from etc.llm_app_env import PLOT_LLM_CONFIG, PLOT_PROMPT_TEMPLATE, PLOT_RESPONSE_SCHEMA, AZURE_OPENAI_CONFIG

class PlotAgent:
    def __init__(self) -> None:
        """Initialize the Plot Agent with an LLM and response parser."""
        self.llm = AzureChatOpenAI(
            deployment_name=AZURE_OPENAI_CONFIG["DEPLOYMENT_NAME"],
            azure_endpoint=AZURE_OPENAI_CONFIG["ENDPOINT"],
            openai_api_version=AZURE_OPENAI_CONFIG["API_VERSION"],
            openai_api_key=AZURE_OPENAI_CONFIG["API_KEY"],  
            model_name=AZURE_OPENAI_CONFIG["MODEL_NAME"],
            temperature=PLOT_LLM_CONFIG["TEMPERATURE"]
        )

        self.PROMPT_TEMPLATE = PLOT_PROMPT_TEMPLATE
        self.response_schemas_dict = PLOT_RESPONSE_SCHEMA
        self.tools = []  # FIX: Added missing initialization

        response_schemas = [
            ResponseSchema(name=item['name'], description=item['description']) 
            for item in self.response_schemas_dict
        ]
        self.output_parser_json = StructuredOutputParser.from_response_schemas(response_schemas)
        self.format_instructions = self.output_parser_json.get_format_instructions()
        self.agent = self.get_agent()

    def parse(self, output):
        """Parse the model output."""
        if "function_call" not in output.additional_kwargs:
            return AgentFinish(return_values={"output": output.content}, log=output.content)

        function_call = output.additional_kwargs["function_call"]
        name = function_call["name"]
        inputs = json.loads(function_call["arguments"])

        if name == "Response":
            return AgentFinish(return_values=inputs, log=str(function_call))

        return AgentActionMessageLog(
            tool=name, tool_input=inputs, log="", message_log=[output]
        )

    def df_schema_to_json(self, df):
        """Convert dataframe schema to JSON with error handling."""
        schema = {}
        if df.empty:
            return schema

        for column in df.columns:
            try:
                column_info = {
                    "dtype": str(df[column].dtype),
                    "nullable": df[column].isnull().any(),
                    "unique_values": df[column].nunique(),
                    "sample_values": df[column].dropna().sample(min(5, df[column].nunique())).tolist()
                }
            except ValueError:
                column_info = {
                    "dtype": str(df[column].dtype),
                    "nullable": df[column].isnull().any(),
                    "unique_values": 0,
                    "sample_values": []
                }
            schema[column] = column_info
        return schema

    def remove_indentation(self, code):
        """Fix indentation removal using textwrap.dedent."""
        return textwrap.dedent(code).strip()

    def get_agent(self):
        """Initialize the prompt agent."""
        prompt = ChatPromptTemplate.from_messages([
            ("system", self.PROMPT_TEMPLATE),
        ])
        
        agent = (
            {
                "user_question": lambda x: x["user_question"],
                "schema_json": lambda x: x["schema_json"],
                "format_instructions": lambda x: x["format_instructions"],
            }
            | prompt
            | self.llm
            | self.parse
        )

        return agent

    def invoke_agent(self, user_question, schema_json):
        """Invoke the agent with user question and schema JSON."""
        agent_executor = AgentExecutor(agent=self.agent, tools=self.tools, verbose=True)
        result = agent_executor.invoke({
            "user_question": user_question, 
            "schema_json": schema_json,
            "format_instructions": self.format_instructions,
        }, return_only_outputs=True)
        
        return result['output'], self.custom_parse_json(result['output'])

    def custom_parse_json(self, llm_response):
        """Parse JSON safely."""
        try:
            json_data = self.output_parser_json.parse(llm_response)
        except:
            try:
                json_data = json.loads(llm_response.split("json")[-1].replace("```", ""))
            except:
                json_data = {"error": "JSON Parsing error"}
        return json_data
