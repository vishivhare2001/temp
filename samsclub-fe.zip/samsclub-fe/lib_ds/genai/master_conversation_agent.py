from langchain.chains import LLMChain
from langchain.memory import ConversationBufferWindowMemory
import json
from langchain.output_parsers import StructuredOutputParser, ResponseSchema
from langchain.prompts import PromptTemplate
from langchain_openai import AzureChatOpenAI
from etc.api_key import API_KEY
from etc.llm_app_env import (
    CONVERSATION_LLM_CONFIG, 
    CONVERSATION_AGENT_TEMPLATE, 
    CONVERSATION_RESPONSE_SCHEMA, 
    AZURE_OPENAI_CONFIG,
    TABLE_COLUMN_DESC
)
import pandas as pd
import tiktoken  # Added for token counting

class ConversationAgent:
    def __init__(self) -> None:
        """Initialize the Master Conversation Agent."""
        self.llm = AzureChatOpenAI(
            deployment_name=AZURE_OPENAI_CONFIG["DEPLOYMENT_NAME"],  
            azure_endpoint=AZURE_OPENAI_CONFIG["ENDPOINT"],
            openai_api_version=AZURE_OPENAI_CONFIG["API_VERSION"], 
            openai_api_key=AZURE_OPENAI_CONFIG["API_KEY"],
            model_name=AZURE_OPENAI_CONFIG["MODEL_NAME"],  
            temperature=CONVERSATION_LLM_CONFIG["TEMPERATURE"]
        )

        self.conversation_agent_prompt = CONVERSATION_AGENT_TEMPLATE
        self.response_schemas_dict = CONVERSATION_RESPONSE_SCHEMA
        self.data_schema_path = TABLE_COLUMN_DESC

        response_schemas = [
            ResponseSchema(name=item['name'], description=item['description']) 
            for item in self.response_schemas_dict
        ]
        self.output_parser_json = StructuredOutputParser.from_response_schemas(response_schemas)
        self.format_instructions = self.output_parser_json.get_format_instructions()

        self.memory = ConversationBufferWindowMemory(k=4, memory_key="chat_history", input_key="user_question")    
        self.conv_chain = self.get_conv_chain()


    def load_database_schema(self):
        schema_df = pd.read_csv(self.data_schema_path, usecols=['table_name', 'table_description', 'columns'])
        schema_json = schema_df.to_dict(orient='records')
        return schema_json

    def count_tokens(self, text, model="gpt-4"):
        """Counts the number of tokens in the input prompt."""
        encoding = tiktoken.encoding_for_model(model)
        return len(encoding.encode(text))

    def get_conv_chain(self):
        """Set up the conversational chain with memory."""
        prompt = PromptTemplate(
            input_variables=["chat_history", "user_question", "db_schema", "format_instructions"],
            template=self.conversation_agent_prompt
        )

        llm_chain = LLMChain(
            llm=self.llm,
            prompt=prompt,
            memory=self.memory
        )
        return llm_chain

    def invoke_agent(self, user_question):
        """Process the user query with intent classification and structured enhancement."""
        schema_json = self.load_database_schema()

        # Construct input message for token count estimation
        input_message = f"{self.conversation_agent_prompt}\nChat History: {self.memory}\nUser Question: {user_question}\nDB Schema: {schema_json}\nFormat Instructions: {self.format_instructions}"

        # Count tokens before calling the agent
        token_count = self.count_tokens(input_message)
        print(f"__________________________Conversation angent___________ Token count before API call: {token_count}")

        results = self.conv_chain.invoke({
            'user_question': user_question,
            "db_schema": schema_json,
            'format_instructions': self.format_instructions
        })

        json_results = self.output_parser_json.parse(results['text'])
        
        detected_intent = json_results.get("Intent", "Unknown")

        return json_results

    def custom_parse_json(self, llm_response):
        """Handle JSON parsing errors gracefully."""
        try:
            return self.output_parser_json.parse(llm_response)
        except:
            try:
                string = llm_response.split("```json")[-1].split("```")[0].replace("```", "")
                json_data = json.loads(string)
            except:
                json_data = {"error": "JSON Parsing error"}
        return json_data