from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain.output_parsers import StructuredOutputParser, ResponseSchema
from langchain_core.pydantic_v1 import BaseModel, Field
from langchain.agents import AgentExecutor
import json
from etc.api_key import API_KEY
from etc.llm_app_env import SELECTOR_LLM_CONFIG, SELECTOR_PROMPT_TEMPLATE, SELECTOR_RESPONSE_SCHEMA, AZURE_OPENAI_CONFIG
from langchain_core.agents import AgentFinish
import pandas as pd

class Response(BaseModel):
    success: str = Field(description="'True' if any table can be selected for the provided question, else 'False'")
    selected_tables: list = Field(description="List of selected table names from the schema.")
    reason: str = Field(description="Reason for selecting tables based on the provided question and schema context.")

class SelectorAgent:
    def __init__(self) -> None:
        self.llm = AzureChatOpenAI(
            deployment_name=AZURE_OPENAI_CONFIG["DEPLOYMENT_NAME"],
            azure_endpoint=AZURE_OPENAI_CONFIG["ENDPOINT"],
            openai_api_version=AZURE_OPENAI_CONFIG["API_VERSION"],
            openai_api_key=AZURE_OPENAI_CONFIG["API_KEY"],
            model_name=AZURE_OPENAI_CONFIG["MODEL_NAME"],
            temperature=AZURE_OPENAI_CONFIG["TEMPERATURE"]
        )

        self.PROMPT_TEMPLATE = SELECTOR_PROMPT_TEMPLATE
        self.response_schemas_dict = SELECTOR_RESPONSE_SCHEMA
        
        response_schemas = [ResponseSchema(name=item['name'], description=item['description']) for item in self.response_schemas_dict]
        self.output_parser_json = StructuredOutputParser.from_response_schemas(response_schemas)
        self.format_instructions = self.output_parser_json.get_format_instructions()
        self.agent = self.get_agent()

    def load_database_schema(self, sql_executor):
        schema_df = pd.read_csv("data/data_schema.csv", usecols=['table_name', 'table_description', 'columns'])
        schema_json = schema_df.to_dict(orient='records')
        return schema_json

    def get_agent(self):
        prompt = ChatPromptTemplate.from_messages([
            ("system", self.PROMPT_TEMPLATE),
        ])


        chain = (
            {
                "user_question": lambda x: x["user_question"],
                "db_schema": lambda x: x["db_schema"],
                "format_instructions": lambda x: x["format_instructions"],
            }
            | prompt
            | self.llm
        )
        return chain

    def invoke_agent(self, user_question, sql_executor):
        schema_json = self.load_database_schema(sql_executor)
        result = self.agent.invoke({
            "user_question": user_question,
            "db_schema": schema_json,
            "format_instructions": self.format_instructions
        })
        result_json = self.output_parser_json.parse(result.content)
        return result_json

    