from langchain_openai import AzureChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.output_parsers import StructuredOutputParser, ResponseSchema
from langchain.agents import AgentExecutor
from langchain_core.pydantic_v1 import BaseModel, Field
import json
from langchain_core.agents import AgentActionMessageLog, AgentFinish
from etc.llm_app_env import DECOMPOSER_LLM_CONFIG, DECOMPOSER_PROMPT_TEMPLATE, DECOMPOSER_RESPONSE_SCHEMA, DATABASE_TABLE_NAME, AZURE_OPENAI_CONFIG
from etc.api_key import API_KEY


class Response(BaseModel):
    """Final response to the question being asked"""
    success: str = Field(description="this should be 'True' if you could generate SQL for the provided question or else 'False'")
    User_question: str = Field(description="Question asked by the user")
    SQL_response: str = Field(description="Generated SQL query for given question")
    Reason: str = Field(description="reasoning or thought behind the generated SQL query")
    sql_description: str = Field(description="short description of generated sql query")

class DecomposerAgent:
    def __init__(self) -> None:
        self.llm = AzureChatOpenAI(
            deployment_name=AZURE_OPENAI_CONFIG["DEPLOYMENT_NAME"],
            azure_endpoint=AZURE_OPENAI_CONFIG["ENDPOINT"],
            openai_api_version=AZURE_OPENAI_CONFIG["API_VERSION"],
            openai_api_key=AZURE_OPENAI_CONFIG["API_KEY"],
            model_name=AZURE_OPENAI_CONFIG["MODEL_NAME"],
            temperature=AZURE_OPENAI_CONFIG["TEMPERATURE"]
        )

        self.decomposer_agent_prompt = DECOMPOSER_PROMPT_TEMPLATE
        self.response_schemas_dict = DECOMPOSER_RESPONSE_SCHEMA

        response_schemas = [ResponseSchema(name=item['name'], description=item['description']) for item in self.response_schemas_dict] 
        self.output_parser_json = StructuredOutputParser.from_response_schemas(response_schemas)
        self.format_instructions = self.output_parser_json.get_format_instructions()
        self.agent_ = self.get_decomposer_agent()



    def parse(self, output):
        """Fix agent response parsing"""
        if isinstance(output, str):
            return AgentFinish(return_values={"output": output}, log=output)

        if "function_call" not in output.additional_kwargs:
            return AgentFinish(return_values={"output": output.content}, log=output.content)

        function_call = output.additional_kwargs["function_call"]
        name = function_call["name"]
        inputs = json.loads(function_call["arguments"])

        if name == "Response":
            return AgentFinish(return_values=inputs, log=str(function_call))

        return AgentActionMessageLog(
            tool=name, tool_input=inputs, log="", message_log=[output]
        )


    def get_decomposer_agent(self):
        prompt = ChatPromptTemplate.from_messages([
            ("system", self.decomposer_agent_prompt),
        ])
        return (
            {
                "user_question": lambda x: x["user_question"],
                "schema_db": lambda x: x["schema_db"],
                "format_instructions": lambda x: x["format_instructions"],
                "database_table_name": lambda x: x["database_table_name"]
            }
            | prompt
            | self.llm
            | self.parse
        )

    def invoke_agent(self, user_question, schema_json):
        agent_executor = AgentExecutor(
            agent=self.agent_, 
            tools=[],  # FIX: Providing an empty tools list
            verbose=True
        )
        results = agent_executor.invoke({
            "user_question": user_question,
            "schema_db": schema_json,
            "format_instructions": self.format_instructions,
            "database_table_name": DATABASE_TABLE_NAME
        }, return_only_outputs=True)
        return results['output'], self.custom_parse_json(results['output'])


    def custom_parse_json(self, llm_response):
        try:
            return self.output_parser_json.parse(llm_response)
        except:
            try:
                json_data = json.loads(llm_response.split("json")[-1].replace("```", ""))
            except:
                json_data = {"error": "JSON Parsing error"}
        return json_data
