from lib_ds.data_loader.bigquery.sql import SQLExecutor
from lib_ds.genai.selector_agent import SelectorAgent
from lib_ds.genai.decomposer_agent import DecomposerAgent
from lib_ds.genai.refiner_agent import RefinerAgent
from lib_ds.genai.master_conversation_agent import ConversationAgent
from lib_ds.genai.plot_agent import PlotAgent
from lib_ds.utils.logger import Logger
from etc.llm_app_env import LOGLEVEL, AZURE_OPENAI_CONFIG
from etc.api_key import API_KEY
from langchain_openai import AzureChatOpenAI

logger = Logger.get_logger(LOGLEVEL=LOGLEVEL)

class MultiAgentProcessor:
    def __init__(self) -> None:
        """Initialize all agents and load schema from BigQuery."""
        self.sql_executor = SQLExecutor()
        self.schema_df = self.sql_executor.load_database_schema_json(output_type="dataframe")
        self.schema_json = self.schema_df.to_dict(orient='records')

        # Initialize all agents
        self.selector_obj = SelectorAgent()
        self.decomp_obj = DecomposerAgent()
        self.refiner_obj = RefinerAgent()
        self.conversation_agent = ConversationAgent()
        self.plot_agent = PlotAgent()

    def select_schema_subset(self, sel_tables_li):
        if isinstance(sel_tables_li, str):  
            sel_tables_li = eval(sel_tables_li)
        
        schema_df_selected = self.schema_df[self.schema_df['table_name'].isin(sel_tables_li)]
        schema_json_selected = schema_df_selected.to_dict(orient='records')
        return schema_json_selected
        
    def execute_selector(self, user_question):
        selector_result = self.selector_obj.invoke_agent(user_question, self.schema_json)
        self.user_question = user_question
        
        # Convert string representation of list to an actual list
        if isinstance(selector_result['selected_tables'], str):
            selector_result['selected_tables'] = eval(selector_result['selected_tables'])  # Convert string to list
        
        self.sel_tables_li = selector_result['selected_tables']
        logger.debug("SELECTOR OUTPUT: {}".format(selector_result))
        return selector_result


    def execute_decomposer(self):
        """Generate SQL query using the Decomposer Agent."""
        schema_json_selected = self.select_schema_subset(self.sel_tables_li)
        thought_str, output_json = self.decomp_obj.invoke_agent(self.user_question, schema_json_selected)
        self.sql_query = output_json.get('SQL_response', '')
        logger.debug("DECOMPOSER OUTPUT: {}".format(output_json))
        return thought_str, output_json

    def execute_refiner(self):
        """Validate and refine SQL query using the Refiner Agent."""
        schema_json_selected = self.select_schema_subset(self.sel_tables_li)
        thought_str, output_json = self.refiner_obj.invoke_agent(self.user_question, schema_json_selected, self.sql_query)
        logger.debug("REFINER OUTPUT: {}".format(output_json))
        final_sql = output_json.get('Final_query', self.sql_query)
        logger.debug("Executing SQL: {}".format(final_sql))
        final_df = self.sql_executor.execute_query(final_sql).to_dataframe()
        return thought_str, output_json, final_df
    
    def execute_conversation_agent(self, user_question):
        """Process conversational context using the Conversation Agent."""
        response = self.conversation_agent.invoke_agent(user_question)
        logger.debug("CONVERSATION AGENT OUTPUT: {}".format(response))
        return response

    def execute_plot_agent(self, user_question):
        """Generate visualization code using the Plot Agent."""
        schema_json_selected = self.select_schema_subset(self.sel_tables_li)
        output_text, parsed_response = self.plot_agent.invoke_agent(user_question, schema_json_selected)
        logger.debug("PLOT AGENT OUTPUT: {}".format(parsed_response))
        return output_text, parsed_response

    def execute_all(self, user_question):
        """Run the full pipeline from conversation processing to SQL execution and visualization."""
        conversation_result = self.execute_conversation_agent(user_question)
        selector_result = self.execute_selector(user_question)
        decomposer_str, decomposer_json = self.execute_decomposer()
        refiner_str, refiner_json, final_df = self.execute_refiner()
        plot_text, plot_json = self.execute_plot_agent(user_question)

        return {
            "conversation_result": conversation_result,
            "selector_result": selector_result,
            "decomposer_result": decomposer_json,
            "refiner_result": refiner_json,
            "final_dataframe": final_df,
            "plot_result": plot_json
        }
