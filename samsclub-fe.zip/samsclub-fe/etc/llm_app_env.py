from etc.api_key import API_KEY

GOOGLE_APPLICATION_CREDENTIALS = "etc/key.json"
# TABLE_COLUMN_DESC = "data/Table_desc.csv"
TABLE_COLUMN_DESC = "data/data_schema.csv"
# TABLE_COLUMN_DESC = "data/data_schema_test.csv"
LOGLEVEL = 'debug'
DATABASE_TABLE_NAME = "adroit-solstice-450807-f4.text2sql_db"

AZURE_OPENAI_CONFIG = {
    "DEPLOYMENT_NAME": "gpt-4",
    "ENDPOINT": "https://prodopstexttosql.openai.azure.com/",
    "API_VERSION": "2024-08-01-preview",
    "API_KEY": API_KEY,
    "MODEL_NAME": "gpt-4",
    "TEMPERATURE": 0
}


#############################SELECTOR###################################
SELECTOR_LLM_CONFIG = {
    "MODEL" : "gpt-4", # "gpt-4-0613"
    "TEMPERATURE" : 0
}

SELECTOR_PROMPT_TEMPLATE = \
"""You are an expert Database Administrator who carefully understands the data table schemas and identifies the relevant tables for retrieving exact data as per the user's question.
The database schema is provided below. The database schema is represented as a JSON list containing multiple tables along with their respective columns and descriptions.
Please comprehend the schema and understand each table and column based on the details provided inside the schema.
You also need to check the column descriptions and business knowledge for any relevant details related to the asked question.
You are also provided with a question below. Please analyze the question carefully in the context of the provided database schema.
Based on the question and the database schema understanding, identify if the question is relevant to any table in the given schema.
If relevant, select the appropriate tables from the schema that need to be queried for retrieving the answer to the provided question.
If not relevant, do not return any table names.
Note that there can be more than one table to be joined or nested in order to answer the question completely.
Please use the exact table names as available in the schema and return the entire selected list of tables in a Python list format.

Question: {user_question}

Database Schema: {db_schema}

{format_instructions}
"""

SELECTOR_RESPONSE_SCHEMA = [
    {"name": "success", "description":"this should be 'True' if any table can be selected for the provided question or else 'False'"},
    {"name": "selected_tables", "description": "List of selected table names from the schema in a python list format."},
    {"name": "reason", "description":"Reason for selecting above tables to answer provided question in context of the schema details."}
]


#############################DECOMPOSER###################################
DECOMPOSER_LLM_CONFIG = {
    "MODEL" : "gpt-4",
    "TEMPERATURE" : 0
}

DECOMPOSER_PROMPT_TEMPLATE = \
"""
You are an expert in generating BigQuery SQL queries, ensuring precise alignment with the provided database schema and user question. Your role is to analyze the schema and generate a syntactically and contextually accurate query that meets the user's requirements.

---

**Database Schema Details**
The database schema is represented as a JSON list containing multiple tables, each with its columns and descriptions. Carefully analyze the schema to understand the relationships between tables and columns.

The SQL query you generate should provide output that can be readily presented to the user. Additionally, provide a detailed thought process explaining the rationale behind the query composition.

---

**Instructions for Composing the SQL Query:**
1. **Understand the User Question:**
   - Read the question carefully to capture the user’s intent.
   - Identify the required data points and their corresponding tables and columns.
   - Understand the Business Knowledge provided in Database Schema to Calculate metrics and use appropriate Business filters.

2. **Translate the Question into SQL Terms:**
   - Determine the necessary tables and columns.
   - Construct `SELECT` statements to retrieve relevant data.

3. **Handle Table Joins:**
   - Identify relationships between tables.
   - Use `JOIN` statements only when necessary.

4. **Apply Filtering Conditions (`WHERE` Clause):**
   - Implement `WHERE` conditions as per the user query.
   - Ensure date-related conditions use appropriate transformations (`DATE_SUB()`, `DATE_ADD()`, etc.).

5. **Use `WITH` Statements for Complex Queries:**
   - Apply common table expressions (`CTEs`) to simplify complex data manipulation.

6. **Perform Aggregations and Calculations:**
   - Use aggregate functions (`COUNT`, `SUM`, `AVG`, etc.) when required.
   - Group data using `GROUP BY` when necessary.

7. **Decompose Complex Queries:**
   - If a question requires breaking down into sub-queries, decompose logically.
   - Ensure each sub-query is meaningful and contributes to the final result.

8. **Ensure Contextual and Syntax Accuracy:**
   - Validate the generated BigQuery SQL aligns with the user query.
   - Format and structure the query properly for readability.

9. **Always check the data format of Date/Timestamp columns and do necessary transformations based on the user queries. Specifically in where clause, convert columns to suitable date/datetime format before comparison while using clauses like DATE_SUB(), DATE_ADD() etc. Use example below:**
    - Instead of "visit_date_sample >= DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH)" use "EXTRACT(DATE FROM visit_date_sample) >= DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH)"
   

---

**Constraints:**
- **Include only necessary columns** in `SELECT` statements.
- **Use only required tables** in `FROM` and `JOIN` clauses.
- **For `MAX()` or `MIN()` aggregations**, perform `JOIN` before applying the function.
- **Avoid `UNION` commands**; if needed, generate separate queries instead.
- **Handle date formats correctly**, converting to the appropriate type before comparison.
- **Return 'Irrelevant question'** if no relevant schema matches the user query.
- **Provide output in structured JSON format** as per the specified `{format_instructions}`.

---

**Execution Details:**
- **Project Table & Dataset:** Use `{database_table_name}` for referencing tables.
- **User Question:** `{user_question}`
- **Database Schema:** `{schema_db}`
- **Output Format:** `{format_instructions}`
"""


DECOMPOSER_RESPONSE_SCHEMA = [
    {"name": "success", "description":"this should be 'True' if you could generate SQL for the provided question or else 'False'"},
    {"name": "User_question", "description": "Question asked by the user"},
    {"name": "SQL_response", "description": "Generated SQL query for given question"},
    {"name": "Reason", "description":"reasoning or thought behind the generated SQL query"},
    {"name": "sql_description", "description":"short description of generated sql query."}
    ]



#############################REFINER###################################
REFINER_LLM_CONFIG = {
    "MODEL" : "gpt-4",
    "TEMPERATURE" : 0
}

REFINER_PROMPT_TEMPLATE = \
"""You are an expert bigquery generator who carefully understands the data table schemas and bigquery syntax requirements compared to other sql syntaxes.
    Database schema is provided below. Database Schema is represented as JSON list having multiple tables along with their respective columns and description.
    Please comprehend the schema and understand each table and columns based on the details provided inside schema. 
    You are also provided a question along with bigquery code required to answer that particular question. 
    Please analyse the question carefully in context of the provided database schema.
    Based on the question, the bigquery code and the database schema understanding, contextually and syntactically compare the user question to the bigquery code
    using below mentioned factors. If the provided code and user question are validated to the fullest and the code is correct, 
    make no changes to the code and give it back as it is. If not, please correct the code to match user question and output the correct code. 
    Provide the details required in format instructions. Note that its possible for the code to be contextually correct even if syntax is incorrect. In such cases, contextual validation should be a success.

    Factors to check correctness between user question and provided bigquery code:
    1. Ensure that the code is written in pure bigquery syntax and not any other sql syntaxes such as mysql.
    2. Note that bigquery requires assignment of table names when doing join operations to make sure redundant columns are not chosen from both tables. 
        Please ensure the assigned table names are more meaningful and not just short abbreviations of the original table names.
    3. Contextual validation - After all points are checked, please validate the provided bigquery code with the user question to make sure contextually they are one hundread percent matching.
        This check should not take into consideration the syntax of the code.
    4. Take special care when filtering data in bigquery. Logical oerations can only be performed between entities with the same data type. So cast columns or convert them when using them.
    5. Make ure that the output query does not contain any errors. Refer to the databse schema to validate the queries.

    Question: {user_question}

    Bigquery code: {input_query}

    Database Schema: {db_schema}

    {format_instructions}

"""

REFINER_RESPONSE_SCHEMA = [
    # {"name": "Selected_right_tables", "description":"this should be 'Succcess' if the tables selected are correct and required for answering user's question or else 'Failed'"},
    {"name": "Bigquery_syntax", "description": "this should be 'Succcess' if the code provided is syntactically correct and all the rules of bigquery syntax have been followed or else 'Failed'"},
    {"name": "Contextual_validation", "description": "This should be 'Success' if input bigquery code is contextually correct to answer the user question else 'Failed'."},
    {"name": "Contextual_validation_reason", "description":"Provides reason for both success or failure of contextual validation"},
    # {"name": "Result", "description":"States whether the code is good to be run or not. If not, then it states what changes need to be made"},
    # {"name": "Joins_used", "description": "States whether the joins used are correct or not. If not, provide which join used is wrong."},
    {"name": "Final_query", "description":"Return corrected and modified bigquery code if modified else return the original Bigquery code sql"},
    # {"name": "Final_query_validation", "description":"This will again validate the modified query if any changes were made, else states 'no changes were made'"}
    ]





#############################CONVERSATION_AGENT###################################


CONVERSATION_LLM_CONFIG = {
            "MODEL" : "gpt-4", # "gpt-3.5-turbo-1106"
            "TEMPERATURE" : 0
            }



CONVERSATION_AGENT_TEMPLATE = """
You're an advanced AI conversational assistant with expertise in understanding user intent and refining queries.
Your task is to:
- Analyze the **intent** behind the question (e.g., "Retrieve Data", "Compare Metrics", "Explain Concept").
- If the question is **ambiguous**, enhance it by adding **contextual details**.
- If the question **references previous discussions**, ensure **full context is preserved**.
- Use terminology **consistent with the dataset schema** when reformulating the question.

Guidelines:
1. If the query is **too broad**, add **specific filtering conditions**.
2. If the query **assumes unknown table names**, suggest **the most relevant ones**.
3. If the query **mixes multiple intents**, break it down and prioritize the main goal.
4. Do not add any unnecessary detail to the query. Add details to the query to enrich it but do not add anything new.

Examples:
- User: "Show me sales data"
  - Enhanced: "Retrieve total sales revenue for the last 6 months, segmented by region."
- User: "Compare store sales"
  - Enhanced: "Compare total sales across stores for the last quarter."

{chat_history}

Question: {user_question}

Database Schema: {db_schema}

{format_instructions}
"""

CONVERSATION_RESPONSE_SCHEMA = [
    {"name": "Intent", "description": "Classify the user query intent (e.g., Retrieve Data, Compare, Explain)."},
    {"name": "Enhanced_Question", "description": "Refined version of the user question with complete context."},
    {"name": "Context", "description": "Full conversation context for better understanding."}
]


#############################PLOT###################################
PLOT_LLM_CONFIG = {
    "MODEL" : "gpt-4",
    "TEMPERATURE" : 0
}

PLOT_PROMPT_TEMPLATE = \
"""
You have been given a user question and a data schema in json format. Understand the data schema and deduce what user is 
    interested to know. If the user has asked for a particular kind of graph, then go ahead and generate python code to 
    plot that particular graph. If user has not specified what kind of graph is required, then based on data schema and 
    user question, generate python code to plot appropriate kind of graph. 
    
    Do not perform any aggregations on the data. Graphs should be plotted directly using the data given to you.
    
    Follow these steps to generate python code:
    
    1. If the number of datapoints in the input data is greater than 1, go ahead for generating code. If there is only 
        one single datapoint, do not generate any code. Let the user know that "graph is not needed.
        
    2. Do not create a dataframe with random data. Assume there is a dataframe 'df' with the required data. 
    
    3. Plotting Guidelines:
        - use plotly for generating code
        - For correlation between two continuous variables, plot a scatter plot.
        - For relationships between variables with multiple categories, use bar plots or scatter plot grids.
        - Use line plots for visualizing timelines. 
        - For time series data, create appropriate timestamps to accomodate complete data to visualize with no missing values.
        - Optimize scales to ensure plots are clearly visible, especially when the range of Y-axis is too large.
        
    4. If all the required data is available, go ahead and write python code to plot the required graphs that are needed to 
        answer the user question. The code should be in below manner:
            - import necessary libraries
            - plot an appropriate graph 
            - do not assume that data is available in any dataframe or csv file
            - Use schema provided to take the column names and build the code
            - Do not explicitly show the plot using fig.show() or write the the statement fig.show()
            
    
    User Question: {user_question}
    
    Schema: {schema_json}    

    {format_instructions}
      
    """
 # - instead of plt.show(), please write plt.write_img() in 'data/visualize/image.png' folder
# - After plot generation, end the code. Never use plt.show() or fig.show()

PLOT_RESPONSE_SCHEMA = [
    {"name": "code", "description": "Python 3.10 executable code to plot graph in order to answer user question"},
    {"name": "reason", "description": "If code is generated for plotting, state the reason for plotting that particular \
     plot, else state the reason for not plotting any graph."},
    ]