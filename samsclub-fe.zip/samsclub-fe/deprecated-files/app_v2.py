import streamlit as st
import pandas as pd
import time
import plotly.express as px
from lib_ds.processor.multi_agent_processor import MultiAgentProcessor
from lib_ds.genai.master_conversation_agent import ConversationAgent
from lib_ds.genai.plot_agent import PlotAgent
from lib_ds.utils.logger import Logger
from etc.llm_app_env import LOGLEVEL

# Initialize Logger
logger = Logger.get_logger(LOGLEVEL=LOGLEVEL)

# Initialize Agents
proc_obj = MultiAgentProcessor()
conversation_agent = ConversationAgent()
plot_agent = PlotAgent()

# Set a fixed page title
st.set_page_config(page_title="Text 2 SQL Helper", layout="wide")

# **Reset Functionality**
def reset_session():
    """Clears the session state and resets the UI properly."""
    st.session_state.clear()
    st.rerun()  # Properly restart the app with a clean session

# **Reset Button**
if st.sidebar.button("🔄 Reset Session"):
    reset_session()

# **Main Title**
st.title("🤖 Text 2 SQL Helper")

# **Sidebar for Settings**
with st.sidebar:
    st.subheader("Settings")
    enable_plotting = st.checkbox("Enable Data Visualization", value=True)
    enable_deep_dive = st.checkbox("Enable Deep Dive Mode", value=False)
    show_agent_reasons = st.checkbox("Show Agent Reasoning", value=False)
    show_sql_queries = st.checkbox("Show SQL Queries", value=False)

    # Initialize session state for chat history
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    if st.session_state.chat_history:
        st.subheader("Chat History")
        for chat in st.session_state.chat_history:
            st.write(f"**User:** {chat['user']}")
            st.write(f"**Bot:** {chat['bot']}")
            st.write("---")

# **Initialize session state variables if they don't exist**
for key in ["conversation_response", "selector_output", "sql_query", "query_result", "plot_generated", "execution_times", "user_modified_query"]:
    if key not in st.session_state:
        st.session_state[key] = None

# **Chat Interface**
st.write("### 💬 Chat with AI")
user_input = st.text_input("Enter your question:")

if user_input:
    with st.spinner("Processing your query..."):
        execution_times = {}

        # Step 1: Conversational Understanding
        start_time = time.time()
        conversation_response = conversation_agent.invoke_agent(user_input)
        execution_times["ConversationAgent"] = round(time.time() - start_time, 2)

        # Extract the enhanced query with detailed context
        reformulated_question = conversation_response["Question"]
        st.session_state.conversation_response = reformulated_question

        # Store chat history
        st.session_state.chat_history.append({"user": user_input, "bot": reformulated_question})

    st.write(f"**Enhanced Query:** {reformulated_question}")
    st.write(f"⏱️ Execution Time: {execution_times['ConversationAgent']}s")

    # Step 2: Allow User to Modify Query
    st.write("### ✏️ Modify Query (Optional)")
    user_query_input = st.text_area("Edit the AI-generated query if needed:", reformulated_question)

    if st.button("Proceed with Query"):
        st.session_state.user_modified_query = user_query_input
        st.success("Query confirmed. Running next steps...")

# Step 3: Structured Data Querying
if st.session_state.user_modified_query:
    with st.spinner("Executing Selector Agent..."):
        start_time = time.time()
        selector_output = proc_obj.execute_selector(st.session_state.user_modified_query)
        execution_times["SelectorAgent"] = round(time.time() - start_time, 2)
        st.session_state.selector_output = selector_output

    if selector_output["success"] == "True":
        st.write("### 🔍 Selected Tables")
        st.json(selector_output["selected_tables"])
        st.write(f"⏱️ Execution Time: {execution_times['SelectorAgent']}s")

        # **Show Reasoning from Selector Agent**
        if show_agent_reasons:
            st.write("### 🤖 Selector Agent Reasoning")
            st.write(selector_output["reason"])

        # Step 4: SQL Generation (Decomposer)
        with st.spinner("Generating SQL Query..."):
            start_time = time.time()
            thought_str, decomposer_output = proc_obj.execute_decomposer()
            execution_times["DecomposerAgent"] = round(time.time() - start_time, 2)
            st.session_state.sql_query = decomposer_output["SQL_response"]

        st.write("### 📝 Generated SQL Query")
        if show_sql_queries:
            st.code(st.session_state.sql_query, language="sql")
        st.write(f"⏱️ Execution Time: {execution_times['DecomposerAgent']}s")

        # **Show Reasoning from Decomposer Agent**
        if show_agent_reasons:
            st.write("### 🤖 Decomposer Agent Reasoning")
            st.write(decomposer_output["Reason"])

        # Step 5: SQL Refinement
        with st.spinner("Refining SQL Query..."):
            start_time = time.time()
            thought_str, refiner_output, query_result = proc_obj.execute_refiner()
            execution_times["RefinerAgent"] = round(time.time() - start_time, 2)
            st.session_state.query_result = query_result

        st.write("### ✅ Final SQL Query")
        if show_sql_queries:
            st.code(refiner_output["Final_query"], language="sql")
        st.write(f"⏱️ Execution Time: {execution_times['RefinerAgent']}s")

        # **Show Reasoning from Refiner Agent**
        if show_agent_reasons:
            st.write("### 🤖 Refiner Agent Reasoning")
            st.write(refiner_output["Contextual_validation_reason"])

        # Display Query Results
        st.write("### 📊 Query Results")
        st.dataframe(st.session_state.query_result)

        # **Deep Dive Mode**
        if enable_deep_dive:
            st.write("## 🔍 Deep Dive Analysis")
            columns = list(st.session_state.query_result.columns)
            selected_columns = st.multiselect("Select columns to explore:", columns, default=columns)
            if selected_columns:
                st.dataframe(st.session_state.query_result[selected_columns])
            st.write("### 📊 Summary Statistics")
            st.write(st.session_state.query_result[selected_columns].describe())
            st.write("### 📈 Quick Visualization")
            chart_type = st.selectbox("Choose a chart type:", ["Bar Chart", "Line Chart", "Scatter Plot"])
            x_axis = st.selectbox("Select X-axis:", selected_columns)
            y_axis = st.selectbox("Select Y-axis:", selected_columns)
            if st.button("Generate Chart"):
                fig = getattr(px, chart_type.lower())(st.session_state.query_result, x=x_axis, y=y_axis)
                st.plotly_chart(fig)

# Show Execution Times
if st.session_state.execution_times:
    st.write("### ⏳ Execution Summary")
    for agent, time_taken in st.session_state.execution_times.items():
        st.write(f"**{agent}:** {time_taken}s")
