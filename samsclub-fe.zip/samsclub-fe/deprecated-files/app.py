import streamlit as st
from lib_ds.processor.multi_agent_processor import MultiAgentProcessor
from lib_ds.genai.master_conversation_agent import ConversationAgent
from lib_ds.utils.logger import Logger
from etc.llm_app_env import LOGLEVEL
from etc.api_key import API_KEY

logger = Logger.get_logger(LOGLEVEL=LOGLEVEL)
proc_obj = MultiAgentProcessor()
conv_agent = ConversationAgent()

st.set_page_config(page_title="Conversational Multi-Agent Collaborator")
st.title("Conversational Multi-Agent Collaborator")

# Initialize session states
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "conversation_step" not in st.session_state:
    st.session_state.conversation_step = "selector"
if "selector_output" not in st.session_state:
    st.session_state.selector_output = None
if "decomposer_output" not in st.session_state:
    st.session_state.decomposer_output = None
if "refiner_output" not in st.session_state:
    st.session_state.refiner_output = None
if "last_user_input" not in st.session_state:
    st.session_state.last_user_input = None

# Display chat history
for chat in st.session_state.chat_history:
    with st.chat_message(chat["role"]):
        st.markdown(chat["message"])

# User input in chat format
user_input = st.chat_input("Type your question...")

if user_input and user_input != st.session_state.last_user_input:
    st.session_state.last_user_input = user_input  # Store last input to prevent re-execution
    st.session_state.chat_history.append({"role": "user", "message": user_input})
    
    with st.chat_message("user"):
        st.markdown(user_input)

    conversation_response = conv_agent.invoke_agent(user_input)
    assistant_message = conversation_response["Question"]

    with st.chat_message("assistant"):
        st.markdown(assistant_message)

    st.session_state.chat_history.append({"role": "assistant", "message": assistant_message})

    # **Step-wise Execution Logic**
    if st.session_state.conversation_step == "selector":
        logger.info(f"Executing Selector with question: {user_input}")

        # Execute selector only once
        if st.session_state.selector_output is None:
            selector_output = proc_obj.execute_selector(user_input)
            if selector_output["success"].lower() == "true":
                st.session_state.selector_output = selector_output
                st.session_state.conversation_step = "decomposer"

                with st.chat_message("assistant"):
                    st.json(selector_output)
                    st.markdown("I have identified the necessary tables. Do you want me to generate the query?")

            else:
                with st.chat_message("assistant"):
                    st.markdown("I couldn't find relevant tables. Please refine your question.")

    elif st.session_state.conversation_step == "decomposer":
        if user_input.lower() in ["yes", "proceed", "generate query"]:
            logger.info("Executing Decomposer")

            # Execute decomposer only once
            if st.session_state.decomposer_output is None:
                proc_obj.sel_tables_li = st.session_state.selector_output["selected_tables"]
                proc_obj.user_question = st.session_state.selector_output["reason"]
                thought_str, decomposer_output = proc_obj.execute_decomposer()

                if decomposer_output["success"].lower() == "false":
                    with st.chat_message("assistant"):
                        st.markdown("I couldn't generate a query. Please refine your question.")
                else:
                    st.session_state.decomposer_output = decomposer_output
                    st.session_state.conversation_step = "refiner"

                    with st.chat_message("assistant"):
                        st.text_area("Decomposer Thought", thought_str)
                        st.json(decomposer_output)
                        st.markdown("Query generated. Should I refine it?")
        else:
            with st.chat_message("assistant"):
                st.markdown("Let me know if you want me to generate the query.")

    elif st.session_state.conversation_step == "refiner":
        if user_input.lower() in ["yes", "refine", "go ahead"]:
            logger.info("Executing Refiner")

            # Execute refiner only once
            if st.session_state.refiner_output is None:
                proc_obj.sql_query = st.session_state.decomposer_output["SQL_response"]
                thought_str, refiner_output, df_table = proc_obj.execute_refiner()
                st.session_state.refiner_output = refiner_output
                st.session_state.conversation_step = "complete"

                with st.chat_message("assistant"):
                    st.text_area("Refiner Thought", thought_str)
                    st.json(refiner_output)
                    st.dataframe(df_table)
                    st.markdown("Here is the refined SQL query and the results.")
        else:
            with st.chat_message("assistant"):
                st.markdown("Let me know if you want me to refine the query.")
