import streamlit as st
import pandas as pd
import time
import plotly.express as px
from lib_ds.processor.multi_agent_processor import MultiAgentProcessor
from lib_ds.genai.master_conversation_agent import ConversationAgent
from lib_ds.genai.plot_agent import PlotAgent
from lib_ds.utils.logger import Logger
from etc.llm_app_env import LOGLEVEL

logger = Logger.get_logger(LOGLEVEL=LOGLEVEL)

proc_obj = MultiAgentProcessor()
conversation_agent = ConversationAgent()
plot_agent = PlotAgent()

st.set_page_config(page_title="Text 2 SQL Helper", layout="wide")

def reset_session():
    """Clears the session state and resets the UI properly."""
    st.session_state.clear()
    st.rerun()  

if st.sidebar.button("🔄 Reset Session"):
    reset_session()

st.title("Text 2 SQL Helper")

with st.sidebar:
    st.subheader("Settings")
    enable_plotting = st.checkbox("Enable Data Visualization", value=True)
    show_agent_reasons = st.checkbox("Show Agent Reasoning", value=True)
    show_sql_queries = st.checkbox("Show SQL Queries", value=True)
    show_feedback_section = st.checkbox("Show Feedback Section", value=False)

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    if st.session_state.chat_history:
        st.subheader("Chat History")
        for chat in st.session_state.chat_history:
            st.write(f"**User:** {chat['user']}")
            st.write(f"**Bot:** {chat['bot']}")
            st.write("---")

for key in ["conversation_response", "selector_output", "sql_query", "query_result", "plot_generated", "execution_times", "user_modified_query", "user_feedback", "rework_mode", "last_enhanced_query"]:
    if key not in st.session_state:
        st.session_state[key] = None

st.write("### 💬 Chat with AI")

if not st.session_state.get("rework_mode", False):
    user_input = st.text_input("Enter your question:")

    if user_input:
        with st.spinner("Processing your query..."):
            st.session_state.execution_times = {}

            start_time = time.time()
            conversation_response = conversation_agent.invoke_agent(user_input)
            st.session_state.execution_times["ConversationAgent"] = round(time.time() - start_time, 2)

            reformulated_question = conversation_response.get("Enhanced_Question", user_input)
            st.session_state.conversation_response = reformulated_question
            st.session_state.last_enhanced_query = reformulated_question

            st.session_state.chat_history.append({"user": user_input, "bot": reformulated_question})

        st.write(f"**Enhanced Query:** {reformulated_question}")
        st.write(f"⏱️ Execution Time: {st.session_state.execution_times['ConversationAgent']}s")

        user_query_input = st.text_area("Modify AI-generated query if needed:", reformulated_question)

        if st.button("Proceed with Query"):
            st.session_state.user_modified_query = user_query_input
            st.session_state.rework_mode = False  # Ensure normal execution mode
            st.success("Query confirmed. Running next steps...")
            st.rerun()

if st.session_state.get("user_modified_query"):
    with st.spinner("Executing Agents..."):
        start_time = time.time()
        selector_output = proc_obj.execute_selector(st.session_state.user_modified_query)
        st.session_state.execution_times["SelectorAgent"] = round(time.time() - start_time, 2)
        st.session_state.selector_output = selector_output

    if selector_output.get("success") == "True":
        st.write("### 🔍 Selected Tables")
        st.json(selector_output.get("selected_tables", []))
        st.write(f"⏱️ Execution Time: {st.session_state.execution_times['SelectorAgent']}s")

        if show_agent_reasons:
            st.write("### 🤖 Selector Agent Reasoning")
            st.write(selector_output.get("reason", "No reasoning available."))

        with st.spinner("Generating SQL Query..."):
            start_time = time.time()
            thought_str, decomposer_output = proc_obj.execute_decomposer()
            st.session_state.execution_times["DecomposerAgent"] = round(time.time() - start_time, 2)
            st.session_state.sql_query = decomposer_output.get("SQL_response", "No SQL generated.")

        st.write("### 📝 Generated SQL Query")
        if show_sql_queries:
            st.code(st.session_state.sql_query, language="sql")
        st.write(f"⏱️ Execution Time: {st.session_state.execution_times['DecomposerAgent']}s")

        if show_agent_reasons:
            st.write("### 🤖 Decomposer Agent Reasoning")
            st.write(decomposer_output.get("Reason", "No reasoning available."))

        with st.spinner("Refining SQL Query..."):
            start_time = time.time()
            thought_str, refiner_output, query_result = proc_obj.execute_refiner()
            st.session_state.execution_times["RefinerAgent"] = round(time.time() - start_time, 2)
            st.session_state.query_result = query_result

        st.write("### 📊 Query Results")
        st.dataframe(st.session_state.query_result)

        if enable_plotting and not st.session_state.query_result.empty:
            with st.spinner("Generating Visualization..."):
                schema_json = {"columns": [{"name": col, "dtype": "unknown"} for col in st.session_state.query_result.columns]}
                _, plot_response = plot_agent.invoke_agent(st.session_state.user_modified_query, schema_json)
                plot_code = plot_response.get("code", "")
                
                if plot_code:
                    exec_globals = {"df": st.session_state.query_result}
                    exec(plot_code, exec_globals)
                    fig = exec_globals.get("fig", None)
                    if fig:
                        st.plotly_chart(fig)
                    else:
                        st.warning("No visualization available for this query.")
                else:
                    st.warning("No visualization available for this query.")

        if show_feedback_section:
            with st.expander("📝 Refine Your Query"):
                st.session_state.user_feedback = st.text_area("Describe the issues with the query:")

                if st.button("Submit Feedback & Rework Query"):
                    st.session_state.rework_mode = True
                    st.success("Processing feedback and refining query...")
                    st.rerun()